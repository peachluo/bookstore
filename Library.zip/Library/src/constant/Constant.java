package constant;

public class Constant {

}
