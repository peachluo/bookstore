package web.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import DB.database;
import web.servlet.base.BaseServlet;
import domain.Category;
import redis.clients.jedis.Jedis;
import utils.DataSourceUtils;
import utils.JSONUtil;
import utils.JedisUtil;
/**
 * ǰ̨����ģ��
 */
@WebServlet("/Category")
public class CategoryServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
	/*
	 * ��ѯ���з���
	 */
	@SuppressWarnings("unused")
	public String findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			System.out.println("---sidemenu��ȡcate---");
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			//��ѯ���з���
//			//�ȴ�redis��ȡ
//			JedisUtil.setJedisPool();
//			Jedis jedis=JedisUtil.getJedisPool().getResource();
			String value=null;
			//��redis��ȡ����
//			if(value==null){
				String sql="select*from category order by cid+0 asc";
				QueryRunner qr=new QueryRunner(DataSourceUtils.getDataSource());
				List<Category> list = qr.query(sql, new BeanListHandler<>(Category.class));
				//����json�ַ���
				if(list!=null&&list.size()>0){
					value=JSONUtil.toJSONString(list);
					response.getWriter().println(value);
				}
				else{
					System.out.println("�޷���ȡjson");
				}
//			}
//			else{
//				System.out.println("��redis��ȡ");
//				response.getWriter().println(value);
//			}
		} catch (SQLException e) {
		}
		System.out.println("---over---");
		return null;
	}
	/*
	 * ����Cate
	 */
	public String addCate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String cname=request.getParameter("cname");
		//��ȡ���һ�е�cid
		String sql="select cid from category order by cid+0 DESC limit 1";
		QueryRunner qr=new QueryRunner(DataSourceUtils.getDataSource());
		Map<String,Object> map = qr.query(sql,new MapHandler());
		int new_cid=Integer.parseInt((String) map.get("cid"))+1;
		String sql2="insert into category values('"+new_cid+"','"+cname+"')";
		System.out.println(sql2);
		qr.update(sql2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	/*
	 * delCate
	 */
	public String delCate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String cid=request.getParameter("cid");
		System.out.println(cid);
		//��ȡ���һ�е�cid
		QueryRunner qr=new QueryRunner(DataSourceUtils.getDataSource());
		String sql2="delete from category where cid='"+cid+"'";
		System.out.println(sql2);
		qr.update(sql2);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
