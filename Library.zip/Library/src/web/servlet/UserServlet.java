package web.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;

import DB.database;
import domain.User;
import utils.DataSourceUtils;
import web.servlet.base.BaseServlet;

/**
 * �û�ģ��
 */
@WebServlet("/User")
public class UserServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
	/*
	 * ��ת��ע��ҳ��
	 */
	public String registUI(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		return "regist.jsp";
	}
	/*
	 * ��ת����½ҳ��
	 */
	public String loginUI(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		return "index1.jsp";
	}
	/*
	 * ��½�ж�
	 */
	public String login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("����servlet��login����");
		database.connect();
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String sql="select*from users where userName ='"+username+"'and password='"+password+"'";
		
		System.out.println(sql);
		
		try {
			database.setst();
			ResultSet rs=database.getst().executeQuery(sql);
			//��½�ɹ�
			if(rs.next()){
				System.out.println("��½�ɹ�");
				String realname=rs.getString("realname");
				int userID=rs.getInt("userID");
				int sisrole=rs.getInt("sysRole");
				String telephone=rs.getString("telephone");
				//�������û�
				User user =new User();
				BeanUtils.populate(user, request.getParameterMap());
				user.setRealname(realname);
				user.setUserID(userID);
				user.setSysrole(sisrole);
				user.setTelephone(telephone);
				//�����û���¼״̬������
				request.getSession().setAttribute("user", user);
				request.getSession().setAttribute("username", username);
				request.getSession().setAttribute("error", "no");
				//�ض�����ҳ
				response.sendRedirect(request.getContextPath());
				database.close_st();
				return null;
			}
			//��½ʧ��
			else{
				System.out.println("��½ʧ��");
				request.getSession().setAttribute("error", "yes");
				database.getst().close();
				return("index1.jsp");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("msg", "�����쳣!"+e);
			return "msg.jsp";
		}
	}
	/*
	 * �˳���¼
	 */
	public String logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//��ջỰ����
		request.getSession().invalidate();
		response.sendRedirect(request.getContextPath());
		return null;
	}
	/*
	 * ����Ա��½�ж�
	 */
	public String login2(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("����servlet��login����");
		database.connect();
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String sql="select*from admin where userName ='"+username+"'and password='"+password+"'";
		
		System.out.println(sql);
		
		try {
			database.setst();
			ResultSet rs=database.getst().executeQuery(sql);
			//��½�ɹ�
			if(rs.next()){
				System.out.println("��½�ɹ�");
				//�����û���¼״̬������
				request.getSession().setAttribute("admin", "ok");
				request.getSession().setAttribute("error", "no");
				//�ض�����ҳ
				response.sendRedirect(request.getContextPath()+"/admin/admin_index.jsp");
				database.disconnect();
				return null;
			}
			//��½ʧ��
			else{
				System.out.println("��½ʧ��");
				request.getSession().setAttribute("error", "yes");
				database.disconnect();
				return("index2.jsp");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("msg", "�����쳣!"+e);
			return "msg.jsp";
		}
	}
	public String changeInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			System.out.println("����changeInfo����");
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			String realname=request.getParameter("name");
			String telephone=request.getParameter("tel");
			User user=(User) request.getSession().getAttribute("user");
			int userID=user.getUserID();
			user.setRealname(realname);
			user.setTelephone(telephone);
			String sql="update users set realname='"+realname+"', telephone='"+telephone+"'where userID="+userID;
			System.out.println(sql);
			QueryRunner qr=new QueryRunner(DataSourceUtils.getDataSource());
			qr.update(sql);
			response.sendRedirect("user_info.jsp");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("msg", "�����쳣!"+e);
			return "msg.jsp";
		}
		return null;
	}
	/*
	 * �����Ա����
	 */
	public String askVip(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			System.out.println("����askVip����");
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			User user=(User) request.getSession().getAttribute("user");
			int userID=user.getUserID();
			user.setSysrole(2);
			String sql="update users set sysRole=2 where userID="+userID;
			System.out.println(sql);
			QueryRunner qr=new QueryRunner(DataSourceUtils.getDataSource());
			qr.update(sql);
			response.getWriter().println();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("msg", "�����쳣!"+e);
			return "msg.jsp";
		}
		return null;
	}
}
