package web.servlet.base;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ͨ�õ�servlet����
 */
@WebServlet("/Base")
public class BaseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			//��ȡ������
			String mName=request.getParameter("method");
			//���������Ϊ�գ�����
			if(mName==null||mName.trim().length()==0){
				mName="index";
			}
			//��ȡ����Ӧ�ķ��� ��registUI
			Method method=this.getClass().getMethod(mName, HttpServletRequest.class,HttpServletResponse.class);
			//��ȡ����return��·������
			String path=(String)method.invoke(this,request,response);
			if(path!=null){
				request.getRequestDispatcher(path).forward(request, response);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
	//ɶ����дִ��Ĭ�Ϸ���
	public String index(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().print("û��д��תҳ��");
		return null;
	}
		

}
